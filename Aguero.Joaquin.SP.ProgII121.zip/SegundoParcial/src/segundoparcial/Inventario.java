package segundoparcial;

import java.io.*;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Inventario<T extends ICSVSerializable & Comparable<T>> {
    private List<T> elementos = new ArrayList<>();

    // Constructor
    public Inventario() {
        // Inicialización, si es necesario
    }

    // Método para agregar un elemento al inventario, con sus excepciones
    public void agregar(T elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("Debe agregar un libro.");
        }

        // Si el elemento es un libro, verifica que no haya otro igual
        if (elemento instanceof Libro) {
            int id = ((Libro) elemento).getId();
            // Si ya existe, lanza el error
            if (elementos.stream().anyMatch(e -> e instanceof Libro && ((Libro) e).getId() == id)) {
                throw new IllegalArgumentException("Ya existe un libro con ese ID.");
            }
        }
        elementos.add(elemento);
    }

    // Método para eliminar un libro del inventario por su ID
    public void eliminarPorId(int id) {
        Optional<T> libroAEliminar = elementos.stream()
                .filter(elemento -> elemento instanceof Libro)
                .filter(elemento -> ((Libro) elemento).getId() == id)
                .findFirst();

        if (libroAEliminar.isPresent()) {
            elementos.remove(libroAEliminar.get());
        } else {
            throw new IllegalArgumentException("No se encontró el libro.");
        }
    }

    // Método para filtrar libros
    public List<T> filtrar(Predicate<T> criterio) {
        if (criterio == null) {
            throw new IllegalArgumentException("Error, al filtrar.");
        }
        return elementos.stream().filter(criterio).collect(Collectors.toList());
    }

    // Método para ordenar elementos
    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    // Método para aplicar una acción a cada elemento
    public void paraCadaElemento(java.util.function.Consumer<T> accion) {
        elementos.forEach(accion);
    }

    // Método para guardar el inventario en un archivo binario
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    // Método para cargar el inventario desde un archivo binario
    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    // Método para guardar el inventario en un archivo CSV
    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                pw.println(elemento.toCSV());
            }
        }
    }

    // Método para cargar el inventario desde el archivo CSV
    public void cargarDesdeCSV(String ruta, Function<String, T> parser) throws IOException {
        File archivo = new File(ruta);
        if (!archivo.exists() || !archivo.canRead()) {
            throw new IOException("El archivo no existe o no se puede leer.");
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                try {
                    T elemento = parser.apply(linea);

                    if (elemento instanceof Libro) {
                        int id = ((Libro) elemento).getId();
                        boolean existe = elementos.stream().anyMatch(e -> e instanceof Libro && ((Libro) e).getId() == id);
                        if (existe) {
                            System.out.println("El libro con ID " + id + " ya existe y no será agregado.");
                        } else {
                            this.agregar(elemento);
                        }
                    } else {
                        this.agregar(elemento);
                    }
                } catch (Exception e) {
                    System.err.println("Error al leer la línea: " + linea);
                }
            }
        }
    }
}