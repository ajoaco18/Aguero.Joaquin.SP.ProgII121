package segundoparcial;

import java.io.Serializable;

public class Libro implements Comparable<Libro>, ICSVSerializable, Serializable {
    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;
    
    // Tira excepciones si los valores ingresados no son validos
    public Libro(int id, String titulo, String autor, Categoria categoria) {
    if (id <= 0) {
        throw new IllegalArgumentException("El ID debe ser positivo.");
    }
    if (titulo == null || titulo.isBlank()) {
        throw new IllegalArgumentException("Error, debe escribir un titulo.");
    }
    if (autor == null || autor.isBlank()) {
        throw new IllegalArgumentException("Error, debe escribir un autor.");
    }
    if (categoria == null) {
        throw new IllegalArgumentException("Error, debe escribir una categoria.");
    }
    this.id = id;
    this.titulo = titulo;
    this.autor = autor;
    this.categoria = categoria;
}

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    // Metodo para comparar los libros por el tipo de id
    @Override
    public int compareTo(Libro o) {
        return Integer.compare(this.id, o.id);
    }
    
    // Metodo para mostrar la info del libro en tipo cadena de texto
    @Override
    public String toString() {
        return "Libro{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", categoria=" + categoria +
                '}';
    }

    // Metodo convierte en formato csv separa por ,
    @Override
    public String toCSV() {
        return id + "," + titulo + "," + autor + "," + categoria.name();
    }
    
    // Metodo para crear un libro
    public static Libro fromCSV(String csvLine) {
        String[] parts = csvLine.split(",");
        return new Libro(
                Integer.parseInt(parts[0]),
                parts[1],
                parts[2],
                Categoria.valueOf(parts[3])
        );
    }
}
