package segundoparcial;


public interface ICSVSerializable {
    // Metodo para devolver la cadena de texto en formato csv
    String toCSV();
    
}
