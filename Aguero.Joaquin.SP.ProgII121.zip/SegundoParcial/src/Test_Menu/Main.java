package Test_Menu;

import java.io.IOException;
import java.util.Comparator;
import java.util.Optional;
import java.util.Scanner;
import segundoparcial.Categoria;
import segundoparcial.Inventario;
import segundoparcial.Libro;

public class Main {
    private static final String RUTA_BINARIO = "src/data/Libros.dat";
    private static final String RUTA_CSV = "src/data/Libros.csv";

    public static void main(String[] args) {
        Inventario<Libro> inventarioLibros = new Inventario<>();
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {

            System.out.println("\n --- Menu de Gestion de Inventario ---");
            System.out.println("1. Agregar un libro");
            System.out.println("2. Mostrar todos los libros");
            System.out.println("3. Filtrar libros por categoria");
            System.out.println("4. Filtrar libros por titulo");
            System.out.println("5. Ordenar libros por ID");
            System.out.println("6. Ordenar libros por titulo");
            System.out.println("7. Guardar inventario en archivo binario");
            System.out.println("8. Cargar inventario desde archivo binario");
            System.out.println("9. Guardar inventario en archivo CSV");
            System.out.println("10. Cargar inventario desde archivo CSV");
            System.out.println("11. Eliminar un libro");
            System.out.println("12. Salir");
            System.out.print("Elija una opcion: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); 
            switch (opcion) {
                case 1:
                    System.out.print("Escriba el ID del libro: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 

                    System.out.print("Escriba el titulo del libro: ");
                    String titulo = scanner.nextLine();

                    System.out.print("Escriba el autor del libro: ");
                    String autor = scanner.nextLine();

                    System.out.println("Categorias: Ciencia, Literatura, Tecnologia, Arte, Historia, Entretenimiento.");
                    System.out.print("Escriba la categoria del libro: ");
                    String categoriaInput = scanner.nextLine().toUpperCase();

                    try {
                        Categoria categoria = Categoria.valueOf(categoriaInput);
                        inventarioLibros.agregar(new Libro(id, titulo, autor, categoria));
                        System.out.println("Libro agregado correctamente.");
                    } catch (IllegalArgumentException e) {
                        System.out.println("\n\nError, Categoria invalida.");
                    }
                    break;

                case 2:
                    System.out.println("\n\nLista de libros en el inventario:");
                    inventarioLibros.paraCadaElemento(System.out::println);
                    break;
                
                case 3:
                    System.out.println("Categorias: Ciencia, literatura, Tecnologia, Arte, Historia, Entretenimiento.");
                    System.out.print("Escriba la categoria para filtrar: ");
                    String categoriaFiltro = scanner.nextLine().toUpperCase();

                    try {
                        Categoria categoria = Categoria.valueOf(categoriaFiltro);
                        inventarioLibros.filtrar(libro -> libro.getCategoria() == categoria)
                                .forEach(System.out::println);
                    } catch (IllegalArgumentException e) {
                        System.out.println("\n\nError, Categoria invalida.");
                    }
                    break;

                case 4:
                    System.out.print("\n\nIngrese una palabra para buscar en los titulos: ");
                    String palabra = scanner.nextLine();

                    inventarioLibros.filtrar(libro -> libro.getTitulo().contains(palabra))
                            .forEach(System.out::println);
                    break;

                case 5:
                    inventarioLibros.ordenar();
                    System.out.println("\n\nLibros ordenados por ID:");
                    inventarioLibros.paraCadaElemento(System.out::println);
                    break;

                case 6:
                    inventarioLibros.ordenar(Comparator.comparing(Libro::getTitulo));
                    System.out.println("\n\nLibros ordenados por titulo:");
                    inventarioLibros.paraCadaElemento(System.out::println);
                    break;

                case 7:
                    try {
                        inventarioLibros.guardarEnArchivo(RUTA_BINARIO);
                        System.out.println("\n\nInventario guardado en archivo binario.");
                    } catch (IOException e) {
                        System.out.println("\n\nError, al guardar el archivo.");
                    }
                    break;

                case 8:
                    try {
                        inventarioLibros.cargarDesdeArchivo(RUTA_BINARIO);
                        System.out.println("\n\nInventario cargado desde archivo binario.");
                    } catch (IOException | ClassNotFoundException e) {
                        System.out.println("Error al cargar el archivo.");
                    }
                    break;

                case 9:
                    try {
                        inventarioLibros.guardarEnCSV(RUTA_CSV);
                        System.out.println("\n\nInventario guardado en el archivo CSV.");
                    } catch (IOException e) {
                        System.out.println("\n\nError, al guardar el archivo CSV.");
                    }
                    break;

                case 10:
                    try {
                        inventarioLibros.cargarDesdeCSV(RUTA_CSV, Libro::fromCSV);
                        System.out.println("\n\nInventario cargado.");
                    } catch (IOException e) {
                        System.out.println("\n\nError, al cargar el archivo CSV.");
                    }
                    break;    

                case 11:
                    System.out.print("\n\nIngrese el ID del libro a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    scanner.nextLine();

                    try {
                        inventarioLibros.eliminarPorId(idEliminar);
                        System.out.println("\n\nLibro eliminado correctamente.");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 12:
                    salir = true;
                    break;

                default:
                    System.out.println("Error, opcion invalida.");
            }
        }
        scanner.close();
        System.out.println("Saliendo...");
    }
}